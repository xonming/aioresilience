"""
Rate Limiting Module

Provides both local (in-memory) and distributed (Redis) rate limiting.

Default import provides LocalRateLimiter:
    from aioresilience import RateLimiter  # LocalRateLimiter

Explicit imports:
    from aioresilience.rate_limiting import LocalRateLimiter, RedisRateLimiter
"""

from .local import LocalRateLimiter

# Try to import RedisRateLimiter, but don't fail if redis is not installed
try:
    from .redis import RedisRateLimiter
    _has_redis = True
except ImportError:
    RedisRateLimiter = None
    _has_redis = False

# Default alias
RateLimiter = LocalRateLimiter

__all__ = [
    "LocalRateLimiter",
    "RedisRateLimiter",
    "RateLimiter",  # Alias for LocalRateLimiter
]
