"""
FastAPI / Starlette Integration

Middleware and dependencies for integrating aioresilience with FastAPI applications.

Usage:
    from fastapi import FastAPI
    from aioresilience import LoadShedder
    from aioresilience.integrations.fastapi import LoadSheddingMiddleware
    
    app = FastAPI()
    load_shedder = LoadShedder()
    app.add_middleware(LoadSheddingMiddleware, load_shedder=load_shedder)
"""

import logging
from typing import Callable
from fastapi import HTTPException, Request, Response, Depends
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.status import HTTP_503_SERVICE_UNAVAILABLE, HTTP_429_TOO_MANY_REQUESTS
from starlette.responses import JSONResponse

logger = logging.getLogger(__name__)


class LoadSheddingMiddleware(BaseHTTPMiddleware):
    """
    FastAPI middleware for load shedding
    
    Automatically rejects requests when system is overloaded.
    
    Example:
        from fastapi import FastAPI
        from aioresilience import LoadShedder
        from aioresilience.integrations.fastapi import LoadSheddingMiddleware
        
        app = FastAPI()
        load_shedder = LoadShedder(
            max_requests=1000,
            cpu_threshold=85.0,
            memory_threshold=85.0
        )
        
        app.add_middleware(LoadSheddingMiddleware, load_shedder=load_shedder)
    """
    
    def __init__(self, app, load_shedder):
        """
        Initialize middleware
        
        Args:
            app: FastAPI/Starlette application
            load_shedder: LoadShedder instance from aioresilience
        """
        super().__init__(app)
        self.load_shedder = load_shedder
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request through load shedder"""
        # Skip health checks and metrics endpoints
        if request.url.path in ["/health", "/metrics", "/ready", "/healthz"]:
            return await call_next(request)
        
        # Determine priority from headers
        priority = request.headers.get("X-Priority", "normal")
        
        # Try to acquire slot
        if not await self.load_shedder.acquire(priority):
            logger.warning(f"Request shed: {request.method} {request.url.path}")
            # Return proper Response instead of raising exception
            return JSONResponse(
                status_code=HTTP_503_SERVICE_UNAVAILABLE,
                content={"detail": "Service temporarily overloaded. Please retry later."},
                headers={"Retry-After": "5"}
            )
        
        try:
            response = await call_next(request)
            return response
        finally:
            await self.load_shedder.release()


def get_client_ip(request: Request) -> str:
    """
    Extract client IP address from request with proxy support.
    
    Checks headers in order:
    1. X-Forwarded-For (from proxy)
    2. X-Real-IP (from nginx)
    3. Direct connection IP
    
    Args:
        request: FastAPI Request object
        
    Returns:
        Client IP address string
    """
    # Check for forwarded headers first
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip
    
    # Fallback to direct connection IP
    if hasattr(request, "client") and request.client:
        return request.client.host
    
    return "unknown"


def rate_limit_dependency(rate_limiter, rate: str):
    """
    Create FastAPI dependency for rate limiting.
    
    Usage:
        from fastapi import FastAPI, Depends
        from aioresilience import RateLimiter  # or LocalRateLimiter, RedisRateLimiter
        from aioresilience.integrations.fastapi import rate_limit_dependency, get_client_ip
        
        app = FastAPI()
        rate_limiter = RateLimiter(service_name="my_service")
        
        @app.get("/api/data", dependencies=[Depends(rate_limit_dependency(rate_limiter, "100/minute"))])
        async def get_data():
            return {"data": "..."}
    
    Args:
        rate_limiter: RateLimiter instance (LocalRateLimiter or RedisRateLimiter)
        rate: Rate limit string (e.g., "100/minute")
        
    Returns:
        FastAPI dependency function
    """
    async def check_rate_limit(request: Request):
        """Check rate limit for the current request"""
        client_ip = get_client_ip(request)
        
        if not await rate_limiter.check_rate_limit(client_ip, rate):
            raise HTTPException(
                status_code=HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Rate limit exceeded: {rate}",
                headers={"Retry-After": "60"}
            )
    
    return check_rate_limit


__all__ = [
    "LoadSheddingMiddleware",
    "get_client_ip",
    "rate_limit_dependency",
]
